<?php
$conn=mysqli_connect("localhost","root","","pubg");
if(!$conn)
{
	echo mysqli_error();
}
?>